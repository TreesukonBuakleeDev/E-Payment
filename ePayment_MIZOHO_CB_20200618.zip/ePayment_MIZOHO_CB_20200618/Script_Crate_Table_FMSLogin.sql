

CREATE TABLE [dbo].[FMSLogin](
	[UserName] [nvarchar](50) NULL,
	[Password] [nvarchar](50) NULL
) ON [PRIMARY]

INSERT INTO [dbo].[FMSLogin]
([UserName], [Password])
VALUES
('ADMIN','p@ssw0rd')


