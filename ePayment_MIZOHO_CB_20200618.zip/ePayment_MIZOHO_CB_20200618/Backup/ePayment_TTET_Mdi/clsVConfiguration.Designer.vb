﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class clsVConfiguration
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(clsVConfiguration))
        Me.btnSave = New System.Windows.Forms.Button
        Me.TxtDBServer = New System.Windows.Forms.TextBox
        Me.btnSee = New System.Windows.Forms.Button
        Me.TxtDBName = New System.Windows.Forms.TextBox
        Me.TxtDBUserID = New System.Windows.Forms.TextBox
        Me.TxtDBPassword = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.TxtFileEx = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.TxtFileErr = New System.Windows.Forms.TextBox
        Me.btnBrowseEx = New System.Windows.Forms.Button
        Me.btnBrowseErr = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtBankCode = New System.Windows.Forms.TextBox
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(86, 275)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(75, 23)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'TxtDBServer
        '
        Me.TxtDBServer.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TxtDBServer.Location = New System.Drawing.Point(89, 13)
        Me.TxtDBServer.Name = "TxtDBServer"
        Me.TxtDBServer.Size = New System.Drawing.Size(204, 20)
        Me.TxtDBServer.TabIndex = 1
        '
        'btnSee
        '
        Me.btnSee.Location = New System.Drawing.Point(177, 275)
        Me.btnSee.Name = "btnSee"
        Me.btnSee.Size = New System.Drawing.Size(75, 23)
        Me.btnSee.TabIndex = 2
        Me.btnSee.Text = "Test"
        Me.btnSee.UseVisualStyleBackColor = True
        '
        'TxtDBName
        '
        Me.TxtDBName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TxtDBName.Location = New System.Drawing.Point(89, 39)
        Me.TxtDBName.Name = "TxtDBName"
        Me.TxtDBName.Size = New System.Drawing.Size(204, 20)
        Me.TxtDBName.TabIndex = 3
        '
        'TxtDBUserID
        '
        Me.TxtDBUserID.Location = New System.Drawing.Point(89, 65)
        Me.TxtDBUserID.Name = "TxtDBUserID"
        Me.TxtDBUserID.Size = New System.Drawing.Size(204, 20)
        Me.TxtDBUserID.TabIndex = 4
        '
        'TxtDBPassword
        '
        Me.TxtDBPassword.Location = New System.Drawing.Point(89, 91)
        Me.TxtDBPassword.Name = "TxtDBPassword"
        Me.TxtDBPassword.Size = New System.Drawing.Size(204, 20)
        Me.TxtDBPassword.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "DBServer"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(15, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "DBName"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(15, 68)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "DBUser"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(15, 94)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(68, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "DBPassword"
        '
        'TxtFileEx
        '
        Me.TxtFileEx.Location = New System.Drawing.Point(80, 13)
        Me.TxtFileEx.Name = "TxtFileEx"
        Me.TxtFileEx.ReadOnly = True
        Me.TxtFileEx.Size = New System.Drawing.Size(165, 20)
        Me.TxtFileEx.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "File Export"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 42)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(48, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "File Error"
        '
        'TxtFileErr
        '
        Me.TxtFileErr.Location = New System.Drawing.Point(80, 39)
        Me.TxtFileErr.Name = "TxtFileErr"
        Me.TxtFileErr.ReadOnly = True
        Me.TxtFileErr.Size = New System.Drawing.Size(165, 20)
        Me.TxtFileErr.TabIndex = 13
        '
        'btnBrowseEx
        '
        Me.btnBrowseEx.Location = New System.Drawing.Point(251, 13)
        Me.btnBrowseEx.Name = "btnBrowseEx"
        Me.btnBrowseEx.Size = New System.Drawing.Size(57, 20)
        Me.btnBrowseEx.TabIndex = 14
        Me.btnBrowseEx.Text = "Browse.."
        Me.btnBrowseEx.UseVisualStyleBackColor = True
        '
        'btnBrowseErr
        '
        Me.btnBrowseErr.Location = New System.Drawing.Point(251, 39)
        Me.btnBrowseErr.Name = "btnBrowseErr"
        Me.btnBrowseErr.Size = New System.Drawing.Size(57, 20)
        Me.btnBrowseErr.TabIndex = 15
        Me.btnBrowseErr.Text = "Browse.."
        Me.btnBrowseErr.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.TxtDBServer)
        Me.GroupBox1.Controls.Add(Me.TxtDBName)
        Me.GroupBox1.Controls.Add(Me.TxtDBUserID)
        Me.GroupBox1.Controls.Add(Me.TxtDBPassword)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(315, 131)
        Me.GroupBox1.TabIndex = 16
        Me.GroupBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.TxtFileEx)
        Me.GroupBox2.Controls.Add(Me.btnBrowseErr)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.btnBrowseEx)
        Me.GroupBox2.Controls.Add(Me.TxtFileErr)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 150)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(315, 73)
        Me.GroupBox2.TabIndex = 17
        Me.GroupBox2.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.GroupBox4)
        Me.GroupBox3.Controls.Add(Me.GroupBox1)
        Me.GroupBox3.Controls.Add(Me.btnSee)
        Me.GroupBox3.Controls.Add(Me.GroupBox2)
        Me.GroupBox3.Controls.Add(Me.btnSave)
        Me.GroupBox3.Location = New System.Drawing.Point(7, 8)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(329, 304)
        Me.GroupBox3.TabIndex = 18
        Me.GroupBox3.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label7)
        Me.GroupBox4.Controls.Add(Me.txtBankCode)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 229)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(315, 44)
        Me.GroupBox4.TabIndex = 18
        Me.GroupBox4.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(15, 21)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 13)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Bank Code"
        '
        'txtBankCode
        '
        Me.txtBankCode.Location = New System.Drawing.Point(80, 18)
        Me.txtBankCode.Name = "txtBankCode"
        Me.txtBankCode.Size = New System.Drawing.Size(165, 20)
        Me.txtBankCode.TabIndex = 0
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'clsVConfiguration
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(348, 324)
        Me.Controls.Add(Me.GroupBox3)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "clsVConfiguration"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Configuration"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents TxtDBServer As System.Windows.Forms.TextBox
    Friend WithEvents btnSee As System.Windows.Forms.Button
    Friend WithEvents TxtDBName As System.Windows.Forms.TextBox
    Friend WithEvents TxtDBUserID As System.Windows.Forms.TextBox
    Friend WithEvents TxtDBPassword As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TxtFileEx As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TxtFileErr As System.Windows.Forms.TextBox
    Friend WithEvents btnBrowseEx As System.Windows.Forms.Button
    Friend WithEvents btnBrowseErr As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtBankCode As System.Windows.Forms.TextBox
End Class
