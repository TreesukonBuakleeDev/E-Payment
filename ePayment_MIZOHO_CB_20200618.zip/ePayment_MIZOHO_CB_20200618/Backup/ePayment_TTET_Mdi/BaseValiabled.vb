﻿Public Class BaseValiabled
    Public Shared SQLServer As String = ""
    Public Shared SQLDatabase As String = ""
    Public Shared SQLUserID As String = ""
    Public Shared SQLPsw As String = ""

    Public Shared Bankcode As String = ""

    Public Shared AccpacUserID As String = ""
    Public Shared AccpacPsw As String = ""
    Public Shared AccpacVersion As String = ""
    Public Shared AccpacCompany As String = ""

    Public Shared FileErr As String = ""
    Public Shared FileEx As String = ""
    Public Shared FileBk As String = ""
    Public Shared FileLog As String = ""
    Public Shared ConnString As String = ""

    Public Shared TaskUser As String = ""
    Public Shared TaskPass As String = ""

    'Public Shared AccpacCOMAPIAccpacSession_definst As New AccpacCOMAPI.AccpacSession

End Class
