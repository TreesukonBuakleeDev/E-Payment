﻿Imports System.Data
Imports System.Data.SqlClient

Public Class clsVConfiguration
    Dim clsW As New clsCWriteLogFile

    Sub New()
        ' This call is required by the Windows Form Designer.
        InitializeComponent()
        ' Add any initialization after the InitializeComponent() call.
    End Sub
    Sub New(ByVal Callby As String)
        InitializeComponent()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        ErrorProvider1.Clear()

        conStr = "Data Source= " & TxtDBServer.Text & " ;Initial Catalog= " & TxtDBName.Text & _
        ";User id=" & TxtDBUserID.Text & " ;password=" & TxtDBPassword.Text & ""
        Try
            connection = New SqlConnection(conStr)
            If connection.State = ConnectionState.Closed Then
                connection.Open()
                If connection.State = ConnectionState.Open Then
                    Config.WritePrivateProfileString("CONFIG", "DBSERVER", BaseClass.Encription.AES_Encrypt(TxtDBServer.Text, "ABCDEF"))
                    Config.WritePrivateProfileString("CONFIG", "DBNAME", BaseClass.Encription.AES_Encrypt(TxtDBName.Text, "ABCDEF"))
                    Config.WritePrivateProfileString("CONFIG", "DBUSERID", BaseClass.Encription.AES_Encrypt(TxtDBUserID.Text, "ABCDEF"))
                    Config.WritePrivateProfileString("CONFIG", "DBPASSWORD", BaseClass.Encription.AES_Encrypt(TxtDBPassword.Text, "ABCDEF"))
                    Config.WritePrivateProfileString("CONFIG", "FILEEX", TxtFileEx.Text)
                    Config.WritePrivateProfileString("CONFIG", "FILEERR", TxtFileErr.Text)
                    Config.WritePrivateProfileString("CONFIG", "BANKCODE", txtBankCode.Text)

                    MessageBox.Show("Complete", "Configuration", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    btnSee.PerformClick()
                    Me.Close()
                End If
            End If
        Catch ex As Exception
            ErrorProvider1.SetError(TxtDBServer, "Invalid Database")
            ErrorProvider1.SetError(TxtDBName, "Invalid Database")
            ErrorProvider1.SetError(TxtDBUserID, "Invalid Database")
            ErrorProvider1.SetError(TxtDBPassword, "Invalid Database")
            clsW.WriteLogError("<Database>/Invalid to Server : " & ex.Message.ToString())
        End Try

    End Sub

    Private Sub btnSee_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSee.Click
        ErrorProvider1.Clear()

        BaseValiabled.SQLServer = BaseClass.Encription.AES_Decrypt(Config.GetPrivateProfileString("CONFIG", "DBSERVER", ""), "ABCDEF")
        BaseValiabled.SQLDatabase = BaseClass.Encription.AES_Decrypt(Config.GetPrivateProfileString("CONFIG", "DBNAME", ""), "ABCDEF")
        BaseValiabled.SQLUserID = BaseClass.Encription.AES_Decrypt(Config.GetPrivateProfileString("CONFIG", "DBUSERID", ""), "ABCDEF")
        BaseValiabled.SQLPsw = BaseClass.Encription.AES_Decrypt(Config.GetPrivateProfileString("CONFIG", "DBPASSWORD", ""), "ABCDEF")

        TxtDBServer.Text = BaseValiabled.SQLServer
        TxtDBName.Text = BaseValiabled.SQLDatabase
        TxtDBUserID.Text = BaseValiabled.SQLUserID
        TxtDBPassword.Text = BaseValiabled.SQLPsw


        BaseValiabled.FileEx = Config.GetPrivateProfileString("CONFIG", "FILEEx", "")
        BaseValiabled.FileErr = Config.GetPrivateProfileString("CONFIG", "FILEERR", "")
        BaseValiabled.Bankcode = Config.GetPrivateProfileString("CONFIG", "BANKCODE", "")
        TxtFileEx.Text = BaseValiabled.FileEx
        TxtFileErr.Text = BaseValiabled.FileErr
        txtBankCode.Text = BaseValiabled.Bankcode
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseEx.Click
        Dim opn As New FolderBrowserDialog
        opn.ShowDialog()
        TxtFileEx.Text = opn.SelectedPath
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseErr.Click
        Dim opn As New FolderBrowserDialog
        opn.ShowDialog()
        TxtFileErr.Text = opn.SelectedPath
    End Sub
End Class