﻿
Public Class clsCSys
    Public Sub ShowChildFormmodule(ByVal f As Form)
        If f.Visible = True Then
            f.BringToFront()
        Else
            f.MdiParent = Form1
            f.Show()
        End If
    End Sub
End Class
