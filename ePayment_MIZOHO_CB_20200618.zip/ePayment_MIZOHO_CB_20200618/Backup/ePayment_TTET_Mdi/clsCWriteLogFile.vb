﻿Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Public Class clsCWriteLogFile

    '   Dim clsW As clsCWriteLogFile

    Public Function WriteLog()
        Return True
    End Function

    Public Sub WriteLogError(ByRef LogData As String)
        CheckExistDirectory()
        Dim File1 As StreamWriter
        'Dim FileName As String = "C:\ePaymentWriteLog\Payment" & Now.ToString("ddMMyyyy") & ".txt"
        Dim FileName As String = BaseValiabled.FileErr & "\Payment" & Now.ToString("ddMMyyyy") & ".txt"
        File1 = My.Computer.FileSystem.OpenTextFileWriter(FileName, True)
        If Not IO.File.Exists(FileName) Then
            System.IO.File.CreateText(FileName).Dispose()
        End If
        File1.WriteLine(Format(Now, "dd/MM/yyyy  HH:mm:ss") & "   " & LogData)
        File1.Close()
        File1 = Nothing
    End Sub

    Private Sub CheckExistDirectory()
        If Not (IO.Directory.Exists(BaseValiabled.FileErr)) Then
            IO.Directory.CreateDirectory(BaseValiabled.FileErr)
        End If
    End Sub
    Public Function SaveExported(ByVal Datagridview1 As DataGridView) As Boolean
        Dim Ret As Boolean = True
        Dim DataForExport As New DataView(Datagridview1.DataSource, "Check = TRUE", "BatchNo", DataViewRowState.CurrentRows)
        Dim dtList As DataTable = DataForExport.ToTable()
        Try
            connection = New SqlConnection(conStr)
            If connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            For i = 0 To dtList.Rows.Count - 1
                ' sql1 = "INSERT INTO FMSEPayEx VALUES(" & dtList.Rows(i)("BatchNo") & "," & Now.ToString("yyyy-MM-dd") & ")"
                sql1 = "INSERT INTO FMSEPayEx VALUES(" & dtList.Rows(i)("BatchNo") & ",@ExportDate)"
                command.Parameters.Clear()
                command.CommandType = CommandType.Text
                command.CommandText = sql1
                command.Connection = connection
                command.Parameters.AddWithValue("@ExportDate", DateTime.Parse(Now))
                Dim result As Integer = command.ExecuteNonQuery
                If result = -1 Then
                    MessageBox.Show("error")
                Else
                    ' MessageBox.Show("Save Batch Exported")
                End If
            Next
        Catch ex As Exception
            WriteLogError("<WriteTextFile>/Export : " & ex.Message.ToString())
            Ret = False
        End Try

        Return Ret
    End Function
End Class
