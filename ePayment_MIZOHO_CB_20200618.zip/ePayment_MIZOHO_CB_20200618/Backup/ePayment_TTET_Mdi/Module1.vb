﻿Imports System.Data.SqlClient
Imports System.Data
Module Module1

    ''Friend conStr As String = "Server=(local);Database=HBTCOM;Trusted_Connection=Yes;"
    ' Friend conStr As String = "Data Source= DEV02-FMS;Initial Catalog=TTEDAT;User id=sa ;password=sa"
    Friend Config As New BaseClass.FILEIO(Application.StartupPath & "\CONFIG.ini")
    Friend conStr As String
    Friend connection As SqlConnection
    Friend command As SqlCommand
    Friend dataSt As DataSet
    Friend adapter As SqlDataAdapter
    Friend bindingSrc As BindingSource
    Friend reader As SqlDataReader
    Friend dataTable As DataTable
    Friend sql1 As String

    Public Function conDB()
        connection = New SqlConnection(conStr)
        If connection.State = ConnectionState.Closed Then
            connection.Open()
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub ReadConfig()
        BaseValiabled.SQLServer = BaseClass.Encription.AES_Decrypt(Config.GetPrivateProfileString("CONFIG", "DBSERVER", ""), "ABCDEF")
        BaseValiabled.SQLDatabase = BaseClass.Encription.AES_Decrypt(Config.GetPrivateProfileString("CONFIG", "DBNAME", ""), "ABCDEF")
        BaseValiabled.SQLUserID = BaseClass.Encription.AES_Decrypt(Config.GetPrivateProfileString("CONFIG", "DBUSERID", ""), "ABCDEF")
        BaseValiabled.SQLPsw = BaseClass.Encription.AES_Decrypt(Config.GetPrivateProfileString("CONFIG", "DBPASSWORD", ""), "ABCDEF")
    End Sub
End Module
