﻿Imports System.Data
Imports System.Data.SqlClient
Public Class clsVLogin
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim status As Boolean = True

        'connection = New SqlConnection(conStr)
        'If connection.State = ConnectionState.Closed Then
        '    connection.Open()
        'End If
        'sql1 = "SELECT * FROM FMSLogin "
        'command = New SqlCommand(sql1, connection)
        'Dim reader As SqlDataReader = command.ExecuteReader()
        'While reader.Read()
        '    If (TextBox1.Text.ToUpper) = reader(0) And (TextBox2.Text.ToUpper) = reader(1) Then
        '        status = True
        '        Exit While
        '    Else
        '        status = False
        '    End If
        'End While
        'If (TextBox1.Text.ToUpper) = "USER" And (TextBox2.Text.ToUpper) = "PASSWORD" Then
        '    status = True
        'Else
        '    status = False
        'End If


        If status Then
            Me.Close()
        Else
            MessageBox.Show("Invalid Username/Password", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If Asc(e.KeyChar) = 13 Then
            Button1.PerformClick()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Application.Exit()
    End Sub
End Class