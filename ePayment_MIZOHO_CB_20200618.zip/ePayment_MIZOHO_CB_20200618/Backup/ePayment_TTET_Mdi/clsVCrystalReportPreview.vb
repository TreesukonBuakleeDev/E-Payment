﻿Imports System.Data
Imports System.Data.SqlClient
Public Class clsVCrystalReportPreview
    Dim clsGet As New clsCGetData
    Dim clsVali As New clsCValidate
    ' Dim dt As New DataTable
    ' Dim _TypeReportReconcile As String
    Dim _ReportType As String
    '  Dim _dtGridview As New DataGridView 

    'เรียกผ่าน Sub New หมด

    Sub New()
        InitializeComponent()
    End Sub

    Sub New(ByVal DataInvalid As DataTable) 'Report Data Invalid
        InitializeComponent()
        If DataInvalid.TableName = "dtInvalid" Then
            PrintValidate(DataInvalid)
        ElseIf DataInvalid.TableName = "dtReferenceInvalid" Then
            PrintReferenceValidate(DataInvalid)
        End If
    End Sub

    Sub New(ByVal dtGridview As DataGridView, Optional ByVal TypeReportReconcile As String = "")
        InitializeComponent()
        PrintReconcile(dtGridview, TypeReportReconcile)
    End Sub

    Private Sub PrintReconcile(ByVal dtGridview As DataGridView, ByVal _TypeReportReconcile As String) 'มี 2 แบบ Summary กับ Detail 
        Dim dt As New DataTable
        Dim DataForReconcile As New DataView(dtGridview.DataSource, "Check = TRUE", "BatchNo", DataViewRowState.CurrentRows)
        dt = DataForReconcile.ToTable()

        dt.WriteXmlSchema("schemaReconcileSum.xml")
        If _TypeReportReconcile = 1 Then
            Dim rpt As New CRReconcile_Summary
            rpt.SetDataSource(dt)
            CrystalReportViewer1.ReportSource = rpt
        Else
            Dim dtDetail As New DataTable
            dtDetail.TableName = "Detail"
            dtDetail.Columns.Add("VendorCode", GetType(String))
            dtDetail.Columns.Add("VendorName", GetType(String))
            dtDetail.Columns.Add("BankAccount", GetType(String))
            dtDetail.Columns.Add("BankCode", GetType(String))
            dtDetail.Columns.Add("BranchCode", GetType(String))
            dtDetail.Columns.Add("Amount", GetType(Double))
            dtDetail.Columns.Add("BatchEntry", GetType(String))
            For i = 0 To dt.Rows.Count - 1
                sql1 = "SELECT R.IDVEND AS VendorCode,R.RMITNAME AS VendorName,R.CODEPSTL AS BankAccount "
                sql1 &= "   ,R.NAMECITY AS BankCode,R.CODESTTE AS BranchCode,E.AMTRMITHC AS Amount "
                sql1 &= "   ,Concat(E.CNTBTCH,'/',E.CNTENTR) AS 'BatchEntry' "
                sql1 &= "FROM APVNR R RIGHT JOIN APTCR E ON R.IDVEND = E.IDVEND "
                sql1 &= "WHERE E.CNTBTCH = " & dt.Rows(i)("BatchNo")
                command = New SqlCommand(sql1, connection)
                adapter = New SqlDataAdapter(command)
                dataSt = New DataSet()
                adapter.Fill(dataSt, "DataDetail")
                For k = 0 To dataSt.Tables("DataDetail").Rows.Count - 1
                    dtDetail.Rows.Add(dataSt.Tables("DataDetail").Rows(k)("VendorCode") _
                                      , dataSt.Tables("DataDetail").Rows(k)("VendorName") _
                                      , dataSt.Tables("DataDetail").Rows(k)("BankAccount") _
                                      , dataSt.Tables("DataDetail").Rows(k)("BankCode") _
                                      , dataSt.Tables("DataDetail").Rows(k)("BranchCode") _
                                      , dataSt.Tables("DataDetail").Rows(k)("Amount") _
                                      , dataSt.Tables("DataDetail").Rows(k)("BatchEntry"))
                Next
            Next

            Dim rpt As New CRReconcile_Detail
            rpt.SetDataSource(dtDetail)
            CrystalReportViewer1.ReportSource = rpt
        End If
    End Sub

    'Sub New(ByVal dtGridview As DataGridView, Optional ByVal TypeReportReconcile As String = "")
    '    InitializeComponent()
    '    Dim DataForReconcile As New DataView(dtGridview.DataSource, "Check = TRUE", "BatchNo", DataViewRowState.CurrentRows)
    '    dt = DataForReconcile.ToTable() 'ตัวแปร มองเห็นทั้ง Form 
    '    '_TypeReportReconcile = TypeReportReconcile
    '    _dtGridview = dtGridview
    '    PrintReconcile(TypeReportReconcile)
    'End Sub

    'Private Sub PrintReconcile(ByVal _TypeReportReconcile As String) 'มี 2 แบบ Summary กับ Detail 
    '    dt.WriteXmlSchema("schemaReconcileSum.xml")
    '    If _TypeReportReconcile = 1 Then
    '        Dim rpt As New CRReconcile_Summary
    '        rpt.SetDataSource(dt)
    '        CrystalReportViewer1.ReportSource = rpt
    '    Else
    '        Dim dtDetail As New DataTable
    '        dtDetail.TableName = "Detail"
    '        dtDetail.Columns.Add("VendorCode", GetType(String))
    '        dtDetail.Columns.Add("VendorName", GetType(String))
    '        dtDetail.Columns.Add("BankAccount", GetType(String))
    '        dtDetail.Columns.Add("BankCode", GetType(String))
    '        dtDetail.Columns.Add("BranchCode", GetType(String))
    '        dtDetail.Columns.Add("Amount", GetType(Double))
    '        dtDetail.Columns.Add("BatchEntry", GetType(String))
    '        '   dtDetail.WriteXmlSchema("schemaReconcileDetail.xml")
    '        For i = 0 To dt.Rows.Count - 1
    '            sql1 = "SELECT R.IDVEND AS VendorCode,R.RMITNAME AS VendorName,R.CODEPSTL AS BankAccount "
    '            sql1 &= "   ,R.NAMECITY AS BankCode,R.CODESTTE AS BranchCode,E.AMTRMITHC AS Amount "
    '            sql1 &= "   ,Concat(E.CNTBTCH,'/',E.CNTENTR) AS 'BatchEntry' "
    '            sql1 &= "FROM APVNR R RIGHT JOIN APTCR E ON R.IDVEND = E.IDVEND "
    '            sql1 &= "WHERE E.CNTBTCH = " & dt.Rows(i)("BatchNo")
    '            command = New SqlCommand(sql1, connection)
    '            adapter = New SqlDataAdapter(command)
    '            dataSt = New DataSet()
    '            adapter.Fill(dataSt, "DataDetail")
    '            For k = 0 To dataSt.Tables("DataDetail").Rows.Count - 1
    '                dtDetail.Rows.Add(dataSt.Tables("DataDetail").Rows(k)("VendorCode") _
    '                                  , dataSt.Tables("DataDetail").Rows(k)("VendorName") _
    '                                  , dataSt.Tables("DataDetail").Rows(k)("BankAccount") _
    '                                  , dataSt.Tables("DataDetail").Rows(k)("BankCode") _
    '                                  , dataSt.Tables("DataDetail").Rows(k)("BranchCode") _
    '                                  , dataSt.Tables("DataDetail").Rows(k)("Amount") _
    '                                  , dataSt.Tables("DataDetail").Rows(k)("BatchEntry"))
    '            Next
    '        Next

    '        Dim rpt As New CRReconcile_Detail
    '        rpt.SetDataSource(dtDetail)
    '        CrystalReportViewer1.ReportSource = rpt
    '    End If
    'End Sub

    Private Sub PrintValidate(ByVal DataInvalid As DataTable)
        ' DataInvalid.WriteXmlSchema("SchemaDtinvalid.xml")
        Dim rpt As New CRDataInvalid
        rpt.SetDataSource(DataInvalid)
        CrystalReportViewer1.ReportSource = rpt
    End Sub

    Private Sub PrintReferenceValidate(ByVal dataReferenceValidate As DataTable)
        dataReferenceValidate.WriteXmlSchema("SchemaDtReferenceInvalid.xml")
        Dim rpt As New CRdataReferenceInvalid
        rpt.SetDataSource(dataReferenceValidate)
        CrystalReportViewer1.ReportSource = rpt
    End Sub

End Class