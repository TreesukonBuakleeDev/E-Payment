

CREATE TABLE [dbo].[FMSLogin](
	[UserName] [nvarchar](50) NULL,
	[Password] [nvarchar](50) NULL
) ON [PRIMARY]



