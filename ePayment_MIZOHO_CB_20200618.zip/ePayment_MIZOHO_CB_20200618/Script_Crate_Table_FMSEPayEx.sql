
CREATE TABLE [dbo].[FMSEPayEx](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[CNTBTCH] [decimal](9, 0) NULL,
	[EXPORTDATE] [date] NULL
) ON [PRIMARY]




